﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Grafitiy.Entity
{
    public class yardenType
    {
        
        string name;

        public yardenType( string name)
        {
           
            this.name=name;
        }
    }
}