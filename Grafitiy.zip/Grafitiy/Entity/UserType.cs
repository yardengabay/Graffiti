﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Grafitiy.Entity
{
    public enum UserType
    {
        Artist,
        ArtLover,
        CityAgent
    }
}