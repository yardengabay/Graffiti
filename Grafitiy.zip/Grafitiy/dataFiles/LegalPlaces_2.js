var json_LegalPlaces_2 = {
"type": "FeatureCollection",
"name": "LegalPlaces_2",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "fid": "1", "id": "1", "address": "Shlomo Ibn Gabirol St 69, Tel Aviv-Yafo", "l_Name": "Artist Wall", "l_Descript": "Need premission from the Tel Aviv Municipality", "is_Legal": "1", "xcoord": 34.780580552111971, "ycoord": 32.081508848565754 }, "geometry": { "type": "Point", "coordinates": [ 34.780580552111971, 32.081508848565754 ] } }
]
}
