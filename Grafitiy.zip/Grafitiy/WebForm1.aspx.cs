﻿using Grafitiy.Entity;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grafitiy
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        public static string pathCurrent = HttpContext.Current.Server.MapPath("~");
        public static string folderName = "dataFiles";
        public static string likesJsonFileName = "grafitiesLikes.json";
        public static string usersJsonFileName = "users.json";
        public static string likesJsonPath = System.IO.Path.Combine(pathCurrent, folderName, likesJsonFileName);
        public static string usersJsonPath = System.IO.Path.Combine(pathCurrent, folderName, usersJsonFileName);

        public static string propertiesJsonPath = System.IO.Path.Combine(pathCurrent, folderName, "properties.json");

        protected void Page_Load(object sender, EventArgs e)
        {
            //string json;
            //yardenType items;

            //using (StreamReader r = new StreamReader(grafitiJsonPath))
            //{
            //    json=r.ReadToEnd().Replace("var yarden = ", "");

            //    items=JsonConvert.DeserializeObject<yardenType>(json);
            //}
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }


        [WebMethod]
        public static Properties GetProperties()
        {
            string json;
            Properties properties;


            using (StreamReader r = new StreamReader(propertiesJsonPath))
            {
                json=r.ReadToEnd();
                properties=JsonConvert.DeserializeObject<Properties>(json);
            }

            List<User> users = getUsersList();

            if(users!=null)
            foreach(User user in users)
            {
                if (user.email==properties.emailUserLogin)
                {
                    properties.userLogin=user;
                }
            }
          


            return properties;
        }

        public static void changeProperties(Properties properties)
        {
           string json=JsonConvert.SerializeObject(properties);

         
            System.IO.File.WriteAllText(propertiesJsonPath, json);
        }

        [WebMethod]
        public static Result newSubscribe(string firstName, string lastName,string email,string password,string userType)
        {
            try
            {
                string json;
                bool alreadtExist = false;
                bool sucessNewSubscribe = false;
                string message="";
                List<User> items;


                using (StreamReader r = new StreamReader(usersJsonPath))
                {
                    json=r.ReadToEnd();
                    items=JsonConvert.DeserializeObject<List<User>>(json);
                }

                if (items!=null)
                {
                    foreach (User user in items)
                    {
                        if (user.email==email)
                        {
                            alreadtExist=true;
                            message="email exist. enter new email";
                            break;
                        }
                    }
                }
               else
                    items=new List<User>();

                if (firstName==String.Empty||lastName==String.Empty||email==String.Empty||password==String.Empty||userType==String.Empty)
                {
                    message="Please fill in all the fields";
                
                }
                else 
                { 

                    if (!alreadtExist)
                    {
                        User newUser = new User(email, password, firstName, lastName, userType, isActive:true);
                        items.Add(newUser);

                        json=JsonConvert.SerializeObject(items.ToArray());
                        System.IO.File.WriteAllText(usersJsonPath, json);

                        sucessNewSubscribe=true;

                    }
                }

                return new Result(sucessNewSubscribe, message);

            }

            catch (Exception ex)
            {
                return null;
            }
        }

        [WebMethod]
        public static Result login(string email,string password)
        {
            string json;
            string message = "";
            bool successLogin = true;
            List<User> items;
            User userReturn = null;

            using (StreamReader r = new StreamReader(usersJsonPath))
            {
                json=r.ReadToEnd();
                items=JsonConvert.DeserializeObject<List<User>>(json);
            }

            if (email==String.Empty|| password==String.Empty)
            {
                message="Username or password incorrect. Try again";
                successLogin=false;
            }

            if (successLogin)
            {
                foreach (User user in items)
                {
                    if (user.email==email&&user.password==password)
                    {
                        userReturn=user;
                        break;
                    }
                }

                if (userReturn==null) 
                {
                    successLogin=false;
                    message ="Username or password incorrect. Try again";
                }

                else if (!userReturn.isActive)
                {
                    message="user is not active";
                    successLogin=false;
                }

            }

            if(userReturn!=null)
                changeProperties(new Properties(successLogin, userReturn.email));
            else
                changeProperties(new Properties(successLogin, String.Empty));

            if (successLogin)
             return new Result(successLogin, message,userReturn);

            return new Result(successLogin, message);
        }


        [WebMethod]
        public static void logout()
        {
            changeProperties(new Properties(false, ""));
        }

        [WebMethod]
        public static void handelActive(string email,bool toActive)
        {
            string json;
            List<User> items;


            using (StreamReader r = new StreamReader(usersJsonPath))
            {
                json=r.ReadToEnd();
                items=JsonConvert.DeserializeObject<List<User>>(json);
            }

            foreach (User user in items)
            {
                if (user.email==email)
                {
                    user.isActive=toActive;
                    break;
                }
            }

             json = JsonConvert.SerializeObject(items);


            System.IO.File.WriteAllText(usersJsonPath, json);


        }



        [WebMethod]
        public static List<User> getUsersList()
        {
            string json;
            List<User> items;


            using (StreamReader r = new StreamReader(usersJsonPath))
            {
                json=r.ReadToEnd();
                items=JsonConvert.DeserializeObject<List<User>>(json);
            }

            return items;
        }


        [WebMethod]
        public static int likeClick(int id)
        {
            string json;
            int newLike = 0;
            List<LikesEntity> items;

            using (StreamReader r = new StreamReader(likesJsonPath))
            {
                json=r.ReadToEnd();
                items = JsonConvert.DeserializeObject<List<LikesEntity>>(json);
            }

            foreach(LikesEntity jsonLikes in items)
            {
                if (jsonLikes.Id==id)
                {
                    jsonLikes.likes++;
                    newLike=jsonLikes.likes;
                }
            }


             json = JsonConvert.SerializeObject(items.ToArray());

            //write string to file
            System.IO.File.WriteAllText(likesJsonPath, json);


            return newLike;
          

        }

        [WebMethod]
        public static int unlikeClick(int id)
        {
            string json;
            int newUnLike = 0;
            List<LikesEntity> items;

            using (StreamReader r = new StreamReader(likesJsonPath))
            {
                json=r.ReadToEnd();
                items=JsonConvert.DeserializeObject<List<LikesEntity>>(json);
            }

            foreach (LikesEntity jsonLikes in items)
            {
                if (jsonLikes.Id==id)
                {
                    jsonLikes.unlikes++;
                    newUnLike=jsonLikes.unlikes;
                }
            }


            json=JsonConvert.SerializeObject(items.ToArray());

            //write string to file
            System.IO.File.WriteAllText(likesJsonPath, json);


            return newUnLike;


        }

        [WebMethod]
        public static int getLikes(int id)
        {
        
            string json;
            List<LikesEntity> items;

            using (StreamReader r = new StreamReader(likesJsonPath))
            {
                json=r.ReadToEnd();
                items=JsonConvert.DeserializeObject<List<LikesEntity>>(json);
            }

            foreach (LikesEntity jsonLikes in items)
            {
                if (jsonLikes.Id==id)
                {
                    return jsonLikes.likes;
                }
            }

            return 0;

        }

        [WebMethod]
        public static int getUnLikes(int id)
        {
            string json;
            List<LikesEntity> items;

            using (StreamReader r = new StreamReader(likesJsonPath))
            {
                json=r.ReadToEnd();
                items=JsonConvert.DeserializeObject<List<LikesEntity>>(json);
            }

            foreach (LikesEntity jsonLikes in items)
            {
                if (jsonLikes.Id==id)
                {
                    return jsonLikes.unlikes;
                }
            }




            return 0;


        }

      

     
    }
}